 $(window).load(function() {
	 $(".wrapper").css('opacity','1');
 });

/* Menu JS Start */
	$(document).ready(function(){
	$('#menu-icon').on('click', function(){
	  $('.navbar').toggleClass('expand');
	  return false;
	});
	
	$('.eu header .navbar ul li a').on('click', function(){
	  $('.navbar').removeClass('expand');
	  $('.menu-box').removeClass('active');
	  $("body").removeClass('add');
	});
	
  });
  $(".menu-box").bind("touch click", function () {
	  $(this).toggleClass("active");
  })
  
  $(document).ready(function(){
	$(".menu-box").on("click",function(){
	$("body").toggleClass("add");
	});
  });

/* Menu JS Ends */



//Form Validator
if($("#formDefualt").length){
    $("#formDefualt input[type=checkbox]").on("change", function(){
        $("#formDefualt").validate().element($(this)[0]);
    });
}
var formDefualt = "#formDefualt";
$(formDefualt).validate({
    
	//Ignore Field is for the Ignoring display None inputs validation
	ignore: [],
    rules: {
        fname: {
            //******this is for the required field
			required: true,
			//******This option is for the minimum number of character
			minlength: 3,
		},
		mobile:{
            required: true,
		},
		email:{
            required: true,
			//******This option for the email address
			 email: true
		},
		checkbox: {
				 required: true,
		},
		
    },
    onfocusout: function (element) {
        $(element).valid();
    },
    errorClass: 'error',
    validClass: 'valid',
    errorElement: 'span',
    highlight: function (element, errorClass, validClass) { 
    $(element).addClass(errorClass).removeClass(validClass); 
    }, 
    unhighlight: function (element, errorClass, validClass) { 
    $(element).removeClass(errorClass).addClass(validClass);
    },
    /*comment this code if you dont want messages*/
    messages: {
        fname: {required: "This field is required.",},
		mobile:{required: "This field is required.",},
		email:{
		required: "This field is required.",
		email: "Please enter a valid email address",
		},
		checkbox:{required: "Please check checkbox"},
		
		
    },
    //***********comment this code if you dont want messages*/
	
	//Add your class instead of .form-msg (after that class error message will show)
	
	errorPlacement: function (error, element) {
        if ($(element).is("input")) {
            error.insertAfter($(element).closest(".form-msg"));
        } 
		else if ($(element).is("select")) {
            error.insertAfter($(element).closest(".form-msg"));
        }
		else {
            error.insertAfter(element)
        }
	},
	//*******In windows.location you can put your link where you want to redirect your form.
	
    /*submitHandler: function (form) {
       window.location = "https://www.google.com"
    }*/
});
//**********On Submit form will be submit 
$(formDefualt + " input[type='submit']").click(function () {
    setTimeout(function () {
        $("input.error").first().focus();
    }, 50)
});

	 
// slider
$('.slider_video').slick({
  dots: true,
  infinite: true,
  speed: 300,
  slidesToShow: 2,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 5000,
  responsive: [
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: true
      }
    },
    
  ]
});

//After Before
$(document).ready(function () {
         
$(window).resize(function(){
    checkScreenSize();
});
         
function checkScreenSize(){
    var newWindowWidth = window.innerWidth;
    if (newWindowWidth < 969) {
    $(".product-list").detach().appendTo(".responsive-list");
               
               
    }
    else
    {
      $(".product-list").detach().appendTo(".product_desktop");
              
    }
}
// Execute on load
checkScreenSize();
// Bind event listener
$(window).resize(checkScreenSize);
});
